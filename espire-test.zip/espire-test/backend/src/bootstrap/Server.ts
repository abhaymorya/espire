import * as express from 'express';
import { Application } from 'express';
const http = require('http');
const io = require('socket.io')();
import { Socket } from './Socket';
import * as cors from 'cors';

export class Server {
    public app: Application;
    public server: any;
    public socket: Socket;

    constructor() {
        this.app = express();
        this.app.use(cors({ origin: "*", credentials: true }));
        this.server = http.createServer(this.app);
        this.socket = new Socket();
    }

    public start(port) {
        this.server.listen(port, () => {
            console.log('Listening to port:', port);
        });
        io.on('connection', (socket) => {
            this.socket.register(socket);
        });
        io.listen(this.server)
    }
}
