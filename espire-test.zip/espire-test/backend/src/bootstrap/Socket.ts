import {UserService} from '../services/UserService';

export class Socket {
    private io;
    private socket;
    private userService: UserService;
    constructor () {
        this.userService = new UserService();
    }

    register(socket) {
        //this.io = io;
        this.socket = socket;
        this.socket.on('login', (data) => this.login(data));
        this.socket.on('logout', () => this.logout());
        this.socket.on('connect_error', (err) => {
            console.log(`connect_error due to ${err}`);
        });
    }

    login(data) {
        console.log(data)
        let res = this.userService.verifyUser(data);
        console.log(res)
        this.socket.emit('verifyUser', res.length>0 ? true : false);
    }

    logout() {
        this.socket.emit('logout', "successfully logout");
    }

    
}
