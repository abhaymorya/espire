/* eslint-disable no-console */
import { Server } from './Server';
import { config } from '../config/app';

export class Application {
    public server: Server;

    constructor() {
        this.server = new Server();
    }

    public boot() {
        this.server.start(config.env.port);
        
    }
}
