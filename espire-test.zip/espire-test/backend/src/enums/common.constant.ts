export const USERS = [
    {
        username: "Tracy",
        password: "test@123"
    },
    {
        username: "Michal",
        password: "test@password"
    }
]