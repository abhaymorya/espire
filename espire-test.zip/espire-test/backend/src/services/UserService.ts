import {USERS} from '../enums/common.constant';

export class UserService {
    public verifyUser(data): any {
        let user: any = {
            username: this.decode(data.username),
            password: this.decode(data.password)
        }
        return USERS.filter((u) => u.username == user.username && u.password == user.password);
    }

    public encode(data) {
        let bufferObj = Buffer.from(data, "utf8");
        return bufferObj.toString("base64");
    }
    
    public decode(data): any {
        let bufferObj = Buffer.from(data, "base64");
        return bufferObj.toString("utf8");
    }
}
