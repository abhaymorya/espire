import { Application } from './bootstrap/Application';

// Initialize the application
const application = new Application();

application.boot();

export default application;
