export const config = Object.freeze({
    env: {
        port: process.env.PORT || 4005,
        name: process.env.NODE_ENV,
    },
});

export default config;
