## Information

- Create a database in mysql and import saguna.sql
- Make changes in .env file as per your DB configuration, by default server will run on 4005 port
- Run npm install
- Run npm start
- Api specification are as follows (Run IN POSTMAN)

## Spcializations
1. GET http://localhost:4005/api/v1/specializations

2. GET http://localhost:4005/api/v1/specializations/:id

3. POST http://localhost:4005/api/v1/specializations
```
{
   "name": "Typescript"
}
```

4. DELETE http://localhost:4005/api/v1/specializations
```
{
    "specializationIds": [1,2]
}
```

## Associates
1. GET http://localhost:4005/api/v1/associates

2. GET http://localhost:4005/api/v1/associates/:id
OR
http://localhost:4005/api/v1/associates?name=jay&email=test5
- Note: It performs search by or condition with name and email query params, else search by single query param

3. POST http://localhost:4005/api/v1/associates

```
{
   "name": "your name",
   "email": "your email",
   "phone": "your phone number",
   "address": "your address",
   "specializationIds": [2,3]
}
```

- Note: specializationIds is optional