import './App.css';
import React, { useState, useEffect } from 'react';
import {login, verifyUser} from './service/socket.service';
import io from 'socket.io-client';

function App() {
  const username = useFormInput('');
  const password = useFormInput('');
  const [submit, setSubmit] = useState(null);
  const [response, setResponse] = useState("");
  const [socket, setSocket] = useState(null);
 
  // handle button click of login form
  const handleLogin = () => {
    setSubmit(true);
    login(username.value, password.value, socket);
  }

  useEffect(() => {
    console.log("submit")
    if(!socket) {
      const url = 'http://localhost:4005';
      setSocket(io(url));
    }
    console.log(submit)
    if(submit) {
      socket.on("verifyUser", (data) => {
        console.log(data);
        setResponse("helo world")
      });
    }
  }, []);

  return (
    <div className="App">
      <div>
        Login<br /><br />
        {response}
        <div>
          Username<br />
          <input type="text" {...username} />
        </div>
        <div style={{ marginTop: 10 }}>
          Password<br />
          <input type="password" {...password}  />
        </div>

        <input type="button" value="Login" onClick={handleLogin} /><br />
      </div>
    </div>
  );
}

const useFormInput = initialValue => {
  const [value, setValue] = useState(initialValue);
 
  const handleChange = e => {
    setValue(e.target.value);
  }
  return {
    value,
    onChange: handleChange
  }
}

export default App;
