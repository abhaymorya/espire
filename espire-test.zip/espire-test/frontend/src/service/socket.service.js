import { Observable, of, observer } from "rxjs";


export function login(username, password, socket) {
    socket.emit("login", {
        username: encode(username), 
        password: encode(password)
    });
}

export function verifyUser(socket) {
    return new Observable((observer) => {
        socket.on("verifyUser", (data) => {
            observer.next(data);
        });
    });
}

function encode(data) {
    let bufferObj = Buffer.from(data, "utf8");
    return bufferObj.toString("base64");
}

function decode(data) {
    let bufferObj = Buffer.from(data, "base64");
    return bufferObj.toString("utf8");
}